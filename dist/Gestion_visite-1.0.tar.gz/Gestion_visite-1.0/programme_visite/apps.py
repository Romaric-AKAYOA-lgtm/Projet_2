from django.apps import AppConfig


class ProgrammeVisiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'programme_visite'
