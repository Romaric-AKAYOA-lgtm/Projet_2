from django.apps import AppConfig


class SecretaireConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'secretaire'
