from django.contrib import admin

# Register your models here.
from .models import Visiteur

admin.site.register(Visiteur)
