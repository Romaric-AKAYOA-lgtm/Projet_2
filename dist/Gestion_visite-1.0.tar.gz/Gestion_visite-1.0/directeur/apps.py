from django.apps import AppConfig


class DirecteurConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'directeur'
